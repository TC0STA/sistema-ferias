from flask import Flask, render_template, request, send_from_directory
import pandas as pd
import os
import sqlite3
import unicodedata
from datetime import datetime, timedelta

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def normalizar_texto(valor):
    texto = str(valor).strip().lower()
    texto = unicodedata.normalize("NFKD", texto)
    return "".join(
        caractere
        for caractere in texto
        if not unicodedata.combining(caractere)
    )

def contem_palavra(texto, palavras):
    return any(palavra in texto for palavra in palavras)

def encontrar_coluna(df, opcoes):
    for coluna in df.columns:
        coluna_normalizada = normalizar_texto(coluna)

        if coluna_normalizada in opcoes:
            return coluna

    for coluna in df.columns:
        coluna_normalizada = normalizar_texto(coluna)

        if contem_palavra(coluna_normalizada, opcoes):
            return coluna

    return None

def ler_excel_com_cabecalho(caminho):
    bruto = pd.read_excel(caminho, header=None)

    for indice, row in bruto.iterrows():
        valores = [
            normalizar_texto(valor)
            for valor in row.tolist()
            if str(valor).strip().lower() != "nan"
        ]

        tem_nome = any(valor in ["nome", "funcionario", "colaborador"] for valor in valores)
        tem_inicio = any("inicio" in valor for valor in valores)
        tem_fim = any(valor == "fim" or "fim" in valor for valor in valores)

        if tem_nome and tem_inicio and tem_fim:
            df = pd.read_excel(caminho, header=indice)
            df.columns = df.columns.str.strip()
            return df

    df = pd.read_excel(caminho)
    df.columns = df.columns.str.strip()
    return df

def carregar_planilha(caminho):
    df = ler_excel_com_cabecalho(caminho)

    coluna_nome = encontrar_coluna(
        df,
        ["nome", "funcionario", "colaborador", "usuario"]
    )
    coluna_inicio = encontrar_coluna(
        df,
        ["inicio", "inicio ferias", "data inicio", "data de inicio"]
    )
    coluna_fim = encontrar_coluna(
        df,
        ["fim", "fim ferias", "data fim", "data de fim"]
    )
    coluna_bloqueio = encontrar_coluna(
        df,
        ["data de bloqueio", "bloqueio", "data bloqueio"]
    )

    if coluna_nome is None or coluna_inicio is None or coluna_fim is None:
        raise ValueError(
            "A planilha precisa ter colunas de Nome, Inicio e Fim."
        )

    colunas = {
        coluna_nome: "Nome",
        coluna_inicio: "Inicio",
        coluna_fim: "Fim"
    }

    if coluna_bloqueio is not None:
        colunas[coluna_bloqueio] = "Data de Bloqueio"

    df = df.rename(columns=colunas)

    df["Nome"] = df["Nome"].astype(str).str.strip()
    df = df[
        (df["Nome"] != "")
        & (df["Nome"].str.lower() != "nan")
    ].copy()

    df["Inicio"] = pd.to_datetime(
        df["Inicio"],
        errors="coerce",
        dayfirst=True
    )

    df["Fim"] = pd.to_datetime(
        df["Fim"],
        errors="coerce",
        dayfirst=True
    )

    if "Data de Bloqueio" not in df.columns:
        df["Data de Bloqueio"] = df["Inicio"] - timedelta(days=1)

    df["Data de Bloqueio"] = pd.to_datetime(
        df["Data de Bloqueio"],
        errors="coerce",
        dayfirst=True
    )

    return df

def planilha_mais_recente():
    arquivos = [
        os.path.join(UPLOAD_FOLDER, nome)
        for nome in os.listdir(UPLOAD_FOLDER)
        if nome.lower().endswith((".xlsx", ".xls"))
    ]

    if not arquivos:
        return None

    return max(arquivos, key=os.path.getmtime)

def formatar_datas(df):
    df = df.copy()

    for coluna in ["Inicio", "Fim", "Data de Bloqueio"]:
        if coluna in df.columns:
            df[coluna] = df[coluna].dt.strftime("%d/%m/%Y")
            df[coluna] = df[coluna].fillna("")

    return df

# ======================
# 🏠 HOME
# ======================
@app.route("/")
def index():
    return render_template("index.html")

# ======================
# 📤 UPLOAD
# ======================
@app.route("/upload", methods=["POST"])
def upload():

    arquivo = request.files["arquivo"]

    if arquivo:

        caminho = os.path.join(
            UPLOAD_FOLDER,
            arquivo.filename
        )

        arquivo.save(caminho)

        try:
            df = carregar_planilha(caminho)
        except ValueError as erro:
            return render_template(
                "resultado.html",
                usuarios=[],
                erro=str(erro)
            )

        dados = []

        for _, row in df.iterrows():

            try:

                nome = str(row["Nome"]).strip()

                bloqueio = row["Data de Bloqueio"]

                if nome == "nan":
                    continue

                dados.append({
                    "Nome": nome,
                    "Bloqueio": bloqueio.date()
                    if pd.notnull(bloqueio)
                    else None
                })

            except:
                continue

        hoje = datetime.now().date()

        usuarios = []

        conn = sqlite3.connect("ferias.db")

        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS bloqueios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT,
                data_bloqueio TEXT,
                data_execucao TEXT,
                UNIQUE(nome, data_bloqueio)
            )
        """)

        for d in dados:

            if d["Bloqueio"] is None:
                continue

            if d["Bloqueio"] == hoje:
                usuarios.append(d["Nome"])

            if d["Bloqueio"] <= hoje:
                cursor.execute("""
                    INSERT OR IGNORE INTO bloqueios
                    (nome, data_bloqueio, data_execucao)
                    VALUES (?, ?, ?)
                """, (
                    d["Nome"],
                    str(d["Bloqueio"]),
                    str(datetime.now())
                ))

        conn.commit()

        conn.close()

        return render_template(
            "resultado.html",
            usuarios=usuarios
        )

    return "Erro no upload"

# ======================
# 📊 DASHBOARD
# ======================
@app.route("/dashboard")
def dashboard():

    caminho = planilha_mais_recente()

    if caminho is None:
        return render_template(
            "dashboard.html",
            hoje=[],
            proximos=[],
            bloqueados=[],
            todos=[],
            labels=[],
            valores=[]
        )

    try:
        df = carregar_planilha(caminho)
    except ValueError as erro:
        return str(erro)

    hoje = datetime.now().date()

    # 🔴 HOJE (inclui bloqueios marcados e quem inicia férias hoje)
    hoje_lista = df[
        (
            df["Data de Bloqueio"].dt.date == hoje
        ) |
        (
            df["Inicio"].dt.date == hoje
        )
    ]

    # 🟡 PRÓXIMOS DIAS
    proximos = df[
        (
            df["Data de Bloqueio"].dt.date > hoje
        ) &
        (
            df["Data de Bloqueio"].dt.date
            <= hoje + pd.Timedelta(days=3)
        )
    ]

    grafico = (
        df.dropna(subset=["Data de Bloqueio"])
        .groupby(df["Data de Bloqueio"].dt.strftime("%d/%m/%Y"))
        .size()
        .sort_index()
    )

    labels = grafico.index.tolist()
    valores = grafico.values.tolist()

    hoje_lista = formatar_datas(hoje_lista)
    proximos = formatar_datas(proximos)
    df = formatar_datas(df)

    # 🟢 HISTÓRICO
    conn = sqlite3.connect("ferias.db")

    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS bloqueios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            data_bloqueio TEXT,
            data_execucao TEXT
        )
    """)

    cursor.execute(
        "SELECT nome FROM bloqueios"
    )

    bloqueados = [
        x[0]
        for x in cursor.fetchall()
    ]

    conn.close()

    return render_template(
        "dashboard.html",
        hoje=hoje_lista.to_dict(orient="records"),
        proximos=proximos.to_dict(orient="records"),
        bloqueados=bloqueados,
        todos=df.to_dict(orient="records"),
        labels=labels,
        valores=valores
    )


@app.route("/detalhe/<secao>")
def detalhe(secao):

    caminho = planilha_mais_recente()

    if caminho is None:
        # para bloqueados ainda vamos buscar do banco
        if secao == "bloqueados":
            conn = sqlite3.connect("ferias.db")
            cursor = conn.cursor()
            cursor.execute("SELECT nome FROM bloqueios")
            bloqueados = [x[0] for x in cursor.fetchall()]
            conn.close()
            return render_template("detalhe.html", secao=secao, items=bloqueados)

        return render_template("detalhe.html", secao=secao, items=[])

    try:
        df = carregar_planilha(caminho)
    except ValueError:
        return render_template("detalhe.html", secao=secao, items=[])

    hoje = datetime.now().date()

    hoje_lista = df[
        (
            df["Data de Bloqueio"].dt.date == hoje
        ) |
        (
            df["Inicio"].dt.date == hoje
        )
    ]

    proximos = df[
        (
            df["Data de Bloqueio"].dt.date > hoje
        ) &
        (
            df["Data de Bloqueio"].dt.date
            <= hoje + pd.Timedelta(days=3)
        )
    ]

    df = formatar_datas(df)
    hoje_lista = formatar_datas(hoje_lista)
    proximos = formatar_datas(proximos)

    # histórico bloqueados
    conn = sqlite3.connect("ferias.db")
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS bloqueios (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, data_bloqueio TEXT, data_execucao TEXT)")
    cursor.execute("SELECT nome FROM bloqueios")
    bloqueados = [x[0] for x in cursor.fetchall()]
    conn.close()

    mapping = {
        'hoje': hoje_lista.to_dict(orient='records'),
        'proximos': proximos.to_dict(orient='records'),
        'bloqueados': bloqueados,
        'todos': df.to_dict(orient='records')
    }

    items = mapping.get(secao, [])

    return render_template('detalhe.html', secao=secao, items=items)

# ======================
# ▶ RODAR
# ======================
@app.route("/historico")
def historico():

    conn = sqlite3.connect("ferias.db")

    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS bloqueios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            data_bloqueio TEXT,
            data_execucao TEXT
        )
    """)

    cursor.execute("""
        SELECT nome, data_bloqueio, data_execucao
        FROM bloqueios
        ORDER BY datetime(data_execucao) DESC
    """)

    dados = cursor.fetchall()

    conn.close()

    return render_template(
        "historico.html",
        dados=dados
    )

if __name__ == "__main__":
    app.run(debug=True)


# rota para servir imagens da pasta Imagens (permite acessar a logo existente)
@app.route('/imagens/<path:filename>')
def imagens(filename):
    return send_from_directory('Imagens', filename)


@app.route('/uploads/<path:filename>')
def uploads_files(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)
